<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class produtos extends CI_Controller {

	public function index()
     // GET/PRODUTOS -> PEGAR TODOS OS PRODUTOS
	{
          // Fazer uma query no banco de dados, que busca todos os produtos
          $produtos = $this->db->get('produtos')->result_array();

          $this->output
                    ->set_content_type('application/json')
                    ->set_status_header(200)
                    ->set_output(json_encode($produtos));
	}
     // GET /produtos/{id}  -> Pegar um produto especifico
     // POST /produtos      -> Adicionar um produto

     public function criar() {
        $produtos = json_decode(file_get_contents('php://input'), true);
        if (!empty($produtos['nome'] && empty($produtos[' preco ']) )) {
               $this->db->insert('produtos' , $produtos);
               $id = $this->db->insert_id();

               $this->output
                    ->set_content_type('application/json')
                    ->set_status_header(201)
                    ->set_output(json_encode([' id ' => $id] + $produtos));
        }else {

               $this->output
                   ->set_content_type('application/json')
                   ->set_status_header(400)
                    ->set_output(json_encode([' erro ' => 'Nome e preco são obrigatorios']));
        }


      
 
	}
     }
// PUT /produtos        -> Editar Produto
// DELETE /produtos   -> Apagar produto



