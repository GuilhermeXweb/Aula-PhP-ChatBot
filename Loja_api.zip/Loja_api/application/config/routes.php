<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['produtos']['GET'] = 'produtos';
$route['produtos']['POST'] = 'produtos/criar';

$route['produtos/$id']['GET'] = 'produtos/buscar' ;
$route['produtos']['PUT'] = 'produtos/atualizar';
$route['produtos']['DELETE'] = 'produtos/apagar';