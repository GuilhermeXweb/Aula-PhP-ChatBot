<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['chatbot/enviar']['post'] = 'welcome/enviar';
$route['chatbot/limpar']['get'] = 'welcome/limpar';
