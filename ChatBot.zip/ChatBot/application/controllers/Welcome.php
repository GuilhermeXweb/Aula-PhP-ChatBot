<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	private $token = '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';
	private $modelo = 'meta-llama/Llama-3.1-8B-Instruct';
	private $system_prompt = 'Você é a atendente virtual da Sabor & Brasa, uma empresa de alimentação especializada em hambúrgueres artesanais, porções, combos e bebidas.Atenda os clientes de forma simpática, rápida e objetiva. Ajude com pedidos, dúvidas sobre o cardápio, preços, horários e entrega.
	Empresa: Sabor & Brasa
	Segmento: Hamburgueria e delivery
	Tom: Amigável, informal e profissional.';

	public function index()
	{
		$data['historico'] = $this->session->userdata('chat') ?? [];
		$this->load->view('chatbot', $data);
	}

	public function limpar() {
		$this->session->unset_userdata('chat');
		redirect('');
	}

	public function enviar() {
		$mensagem = $this->input->post('mensagem');
		$historico = $this->session->userdata('chat') ?? [];

		$historico[] = [
			'role' => 'user',
			'content' => $mensagem
		];

		// corta as primeiras mensagens ,deixando somente as ultimas 10

		$resposta = $this->perguntar_ia($historico);
		$historico[] = [
			'role' => 'assistant',
			'content' => $resposta
		];

		$this->session->set_userdata('chat', $historico);

		redirect('');
	}

	private function perguntar_ia($mensagem) {
		// 01 criar url		
		$url = 'https://router.huggingface.co/v1/chat/completions';

		// 02 montar o corpo da requisição
		$body = json_encode([
			'model' =>$this->modelo,
			'messages' => $mensagem
		]);
	
		// 03 iniciar a cURL
		$ch = curl_init($url);

		// 04 vamos evitar que ele escreva a resposta na tela
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		// 05 aqui vamos falar que a requisição e do tipo POST
		curl_setopt($ch, CURLOPT_POST, true);

		// 06 aqui falamos quais dados vão ser enviados pelo corpo da requisição
		curl_setopt($ch, CURLOPT_POSTFIELDS, $body);

		// 07 aqui falamos quais os dados vão pelo header da requisição 
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Authorization: Bearer ' . $this->token,
			'Content-Type : Application/json'
		]);

		// 08 executa e fecha a sessão
		$retorno = curl_exec($ch);
		curl_close($ch);

		// 09 como a resposta vai vim em json vamos converter ela
		$dados = json_decode($retorno);

		// 10 a fala do bot fica naquele caminho que vimos no postman
		if (isset($dados->choices[0]->message->content)) {
			return $dados->choices[0]->message->content;
		}

		return 'Não foi possivel gerar uma resposta';
	}
}