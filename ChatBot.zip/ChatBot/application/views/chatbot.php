<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Mr Bot Motivation</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        :root {
            --roxo: #6c4cff;
            --azul: #287bff;
            --azul-escuro: #111936;
            --fundo: #080b18;
            --card: #10162a;
            --texto: #ffffff;
            --texto-secundario: #aeb7d0;
            --bot: #1a223b;
        }

        /* ================================
           FUNDO
        ================================= */

        body {
            font-family: 'Segoe UI', Arial, sans-serif;

            background:
                radial-gradient(
                    circle at 20% 20%,
                    rgba(108, 76, 255, .20),
                    transparent 30%
                ),
                radial-gradient(
                    circle at 80% 80%,
                    rgba(40, 123, 255, .15),
                    transparent 30%
                ),
                var(--fundo);

            min-height: 100vh;

            display: flex;
            justify-content: center;
            align-items: center;

            padding: 20px;

            color: var(--texto);
        }

        /* ================================
           LUZES DO FUNDO
        ================================= */

        body::before,
        body::after {
            content: "";

            position: fixed;

            width: 250px;
            height: 250px;

            border-radius: 50%;

            filter: blur(90px);

            opacity: .25;

            z-index: -1;

            animation:
                flutuar 8s ease-in-out infinite alternate;
        }

        body::before {
            background: #6c4cff;

            top: 5%;
            left: 5%;
        }

        body::after {
            background: #008cff;

            right: 5%;
            bottom: 5%;

            animation-delay: 2s;
        }

        /* ================================
           CHAT
        ================================= */

        .chat {
            width: 100%;
            max-width: 520px;

            height: 82vh;
            min-height: 520px;

            background: rgba(16, 22, 42, .90);

            border: 1px solid rgba(255,255,255,.08);

            border-radius: 24px;

            box-shadow:
                0 30px 80px rgba(0,0,0,.55),
                0 0 40px rgba(108,76,255,.10);

            backdrop-filter: blur(20px);

            overflow: hidden;

            display: flex;
            flex-direction: column;

            animation: aparecer .7s ease-out;
        }

        /* ================================
           CABEÇALHO
        ================================= */

        .cabecalho {
            position: relative;

            background:
                linear-gradient(
                    135deg,
                    #171d3b,
                    #352275,
                    #1d4d99
                );

            color: #fff;

            padding: 18px 20px;

            display: flex;

            justify-content: space-between;
            align-items: center;

            border-bottom: 1px solid rgba(255,255,255,.08);
        }

        .cabecalho::after {
            content: "";

            position: absolute;

            left: 0;
            bottom: 0;

            width: 100%;
            height: 2px;

            background:
                linear-gradient(
                    90deg,
                    transparent,
                    #8d7aff,
                    #42a5ff,
                    transparent
                );

            animation: brilho 3s linear infinite;
        }

        .cabecalho h1 {
            font-size: 18px;

            font-weight: 700;

            letter-spacing: .3px;
        }

        /* Indicador online */

        .cabecalho h1::before {
            content: "";

            display: inline-block;

            width: 9px;
            height: 9px;

            margin-right: 8px;

            background: #35e58a;

            border-radius: 50%;

            box-shadow: 0 0 10px #35e58a;

            animation: pulsar 1.8s infinite;
        }

        /* Botão limpar */

        .cabecalho a {
            color: #fff;

            font-size: 12px;

            text-decoration: none;

            background: rgba(255,255,255,.12);

            border: 1px solid rgba(255,255,255,.10);

            padding: 7px 12px;

            border-radius: 10px;

            transition: .25s ease;
        }

        .cabecalho a:hover {
            background: rgba(255,255,255,.22);

            transform: translateY(-2px);
        }

        /* ================================
           ÁREA DAS MENSAGENS
        ================================= */

        .mensagens {
            flex: 1;

            padding: 22px 18px;

            overflow-y: auto;

            display: flex;
            flex-direction: column;

            gap: 14px;

            scroll-behavior: smooth;
        }

        /* Scrollbar */

        .mensagens::-webkit-scrollbar {
            width: 5px;
        }

        .mensagens::-webkit-scrollbar-track {
            background: transparent;
        }

        .mensagens::-webkit-scrollbar-thumb {
            background: #343d61;

            border-radius: 10px;
        }

        /* ================================
           MENSAGENS
        ================================= */

        .msg {
            position: relative;

            max-width: 82%;

            padding: 12px 16px;

            border-radius: 17px;

            line-height: 1.5;

            font-size: 14px;

            white-space: pre-wrap;
        }

        /* ================================
           MENSAGEM DO BOT
        ================================= */

        .msg.bot {
            align-self: flex-start;

            background:
                linear-gradient(
                    135deg,
                    #1a223b,
                    #202b49
                );

            color: #e9edff;

            border: 1px solid rgba(255,255,255,.06);

            border-bottom-left-radius: 5px;

            box-shadow:
                0 8px 20px rgba(0,0,0,.18);

            animation:
                mensagemBot .45s
                cubic-bezier(.2,.8,.2,1);
        }

        /* ================================
           MENSAGEM DO USUÁRIO
        ================================= */

        .msg.user {
            align-self: flex-end;

            background:
                linear-gradient(
                    135deg,
                    #6044e8,
                    #287bff
                );

            color: #fff;

            border-bottom-right-radius: 5px;

            box-shadow:
                0 8px 25px rgba(40,123,255,.20);

            animation:
                mensagemUsuario .45s
                cubic-bezier(.2,.8,.2,1);
        }

        .msg:hover {
            transform: translateY(-2px);

            transition:
                transform .2s ease;
        }

        /* ================================
           MENSAGEM VAZIA
        ================================= */

        .vazio {
            color: var(--texto-secundario);

            text-align: center;

            margin: auto;

            font-size: 14px;

            padding: 30px;

            animation:
                flutuarTexto 3s
                ease-in-out infinite;
        }

        .vazio::before {
            content: "✦";

            display: block;

            color: #806cff;

            font-size: 35px;

            margin-bottom: 10px;

            text-shadow:
                0 0 20px #6c4cff;
        }

        /* ================================
           INDICADOR DE DIGITAÇÃO
        ================================= */

        .digitando {
            display: flex;

            align-items: center;

            gap: 5px;

            width: fit-content;

            min-width: 58px;

            height: 40px;

            padding: 10px 14px !important;

            background:
                linear-gradient(
                    135deg,
                    #1a223b,
                    #202b49
                );

            border-bottom-left-radius: 5px;

            animation:
                mensagemBot .35s ease-out;
        }

        .digitando span {
            width: 6px;
            height: 6px;

            background: #8d9aff;

            border-radius: 50%;

            display: block;

            box-shadow:
                0 0 8px rgba(141,154,255,.5);

            animation:
                digitando 1.4s
                infinite ease-in-out;
        }

        .digitando span:nth-child(2) {
            animation-delay: .2s;
        }

        .digitando span:nth-child(3) {
            animation-delay: .4s;
        }

        /* ================================
           FORMULÁRIO
        ================================= */

        form {
            display: flex;

            gap: 9px;

            padding: 15px;

            background:
                rgba(8,11,24,.65);

            border-top:
                1px solid rgba(255,255,255,.07);
        }

        /* ================================
           INPUT
        ================================= */

        input[type="text"] {
            flex: 1;

            padding: 13px 17px;

            background: #171d32;

            color: #fff;

            border: 1px solid #2b3557;

            border-radius: 22px;

            font-size: 14px;

            outline: none;

            transition:
                border .25s ease,
                box-shadow .25s ease,
                background .25s ease;
        }

        input[type="text"]::placeholder {
            color: #7883a3;
        }

        input[type="text"]:focus {
            background: #1b2340;

            border-color: #6c4cff;

            box-shadow:
                0 0 0 3px rgba(108,76,255,.12),
                0 0 20px rgba(108,76,255,.10);
        }

        /* ================================
           BOTÃO ENVIAR
        ================================= */

        button {
            position: relative;

            width: 47px;
            height: 47px;

            flex-shrink: 0;

            border: none;

            border-radius: 50%;

            background:
                linear-gradient(
                    135deg,
                    #6c4cff,
                    #287bff
                );

            color: #fff;

            font-size: 18px;

            cursor: pointer;

            display: flex;

            justify-content: center;
            align-items: center;

            box-shadow:
                0 8px 20px rgba(40,123,255,.30);

            transition:
                transform .2s ease,
                box-shadow .2s ease;
        }

        button:hover {
            transform:
                scale(1.08)
                rotate(-5deg);

            box-shadow:
                0 10px 30px
                rgba(108,76,255,.45);
        }

        button:active {
            transform: scale(.92);
        }

        /* Anel animado */

        button::before {
            content: "";

            position: absolute;

            inset: -3px;

            border-radius: 50%;

            border:
                1px solid
                rgba(108,76,255,.4);

            animation:
                pulsarBotao 2s infinite;
        }

        /* ================================
           ANIMAÇÕES
        ================================= */

        @keyframes aparecer {

            from {
                opacity: 0;

                transform:
                    translateY(30px)
                    scale(.97);
            }

            to {
                opacity: 1;

                transform:
                    translateY(0)
                    scale(1);
            }
        }

        /* MENSAGEM DO USUÁRIO */

        @keyframes mensagemUsuario {

            from {
                opacity: 0;

                transform:
                    translateX(50px)
                    translateY(10px)
                    scale(.85);
            }

            to {
                opacity: 1;

                transform:
                    translateX(0)
                    translateY(0)
                    scale(1);
            }
        }

        /* MENSAGEM DO BOT */

        @keyframes mensagemBot {

            from {
                opacity: 0;

                transform:
                    translateX(-25px)
                    translateY(10px)
                    scale(.95);
            }

            to {
                opacity: 1;

                transform:
                    translateX(0)
                    translateY(0)
                    scale(1);
            }
        }

        @keyframes pulsar {

            0%, 100% {
                transform: scale(1);

                opacity: 1;
            }

            50% {
                transform: scale(1.35);

                opacity: .65;
            }
        }

        @keyframes pulsarBotao {

            0% {
                transform: scale(1);

                opacity: .7;
            }

            70% {
                transform: scale(1.25);

                opacity: 0;
            }

            100% {
                transform: scale(1.25);

                opacity: 0;
            }
        }

        @keyframes flutuar {

            from {
                transform:
                    translate(0, 0);
            }

            to {
                transform:
                    translate(30px, -25px);
            }
        }

        @keyframes flutuarTexto {

            0%, 100% {
                transform:
                    translateY(0);
            }

            50% {
                transform:
                    translateY(-6px);
            }
        }

        @keyframes brilho {

            0% {
                opacity: .3;

                transform:
                    translateX(-30%);
            }

            50% {
                opacity: 1;
            }

            100% {
                opacity: .3;

                transform:
                    translateX(30%);
            }
        }

        @keyframes digitando {

            0%,
            60%,
            100% {
                transform:
                    translateY(0);

                opacity: .35;
            }

            30% {
                transform:
                    translateY(-5px);

                opacity: 1;
            }
        }

        /* ================================
           RESPONSIVO
        ================================= */

        @media (max-width: 600px) {

            body {
                padding: 0;
            }

            .chat {
                height: 100vh;

                min-height: 100vh;

                max-width: none;

                border-radius: 0;

                border: none;
            }

            .mensagens {
                padding: 18px 14px;
            }

            .msg {
                max-width: 88%;
            }
        }

    </style>
</head>


<body>

    <div class="chat">

        <!-- CABEÇALHO -->

        <div class="cabecalho">

            <h1>
                Mr Bot — Motivation
            </h1>

            <a href="<?= site_url('chatbot/limpar') ?>">
                Limpar
            </a>

        </div>


        <!-- MENSAGENS -->

        <div class="mensagens" id="mensagens">

            <?php if (empty($historico)): ?>

                <p class="vazio">
                    Olá! 👋<br>
                    Estou aqui para te ajudar a evoluir.
                </p>

            <?php else: ?>

                <?php foreach ($historico as $msg): ?>

                    <div class="msg <?= $msg['role'] === 'user' ? 'user' : 'bot' ?>">
                        <?= $msg['content'] ?>
                    </div>

                <?php endforeach; ?>

            <?php endif; ?>

        </div>


        <!-- FORMULÁRIO -->

        <form
            action="<?= site_url('chatbot/enviar') ?>"
            method="post"
            id="chatForm"
        >

            <input
                type="text"
                name="mensagem"
                placeholder="Conte-me o que está acontecendo..."
                autocomplete="off"
                required
                autofocus
                id="mensagemInput"
            >

            <button
                type="submit"
                id="botaoEnviar"
                aria-label="Enviar mensagem"
            >
                ➤
            </button>

        </form>

    </div>


<script>

    /* =================================
       ELEMENTOS
    ================================= */

    var caixa =
        document.getElementById('mensagens');

    var formulario =
        document.getElementById('chatForm');

    var input =
        document.getElementById('mensagemInput');

    var botao =
        document.getElementById('botaoEnviar');


    /* =================================
       SCROLL AUTOMÁTICO
    ================================= */

    caixa.scrollTop =
        caixa.scrollHeight;


    /* =================================
       ENVIO DA MENSAGEM
    ================================= */

    formulario.addEventListener(
        'submit',
        function () {

            /* Guarda a mensagem antes de qualquer alteração */

            var texto =
                input.value.trim();


            /* Se estiver vazio, não faz nada */

            if (!texto) {
                return;
            }


            /* =================================
               CRIA MENSAGEM DO USUÁRIO
            ================================= */

            var mensagemUsuario =
                document.createElement('div');

            mensagemUsuario.className =
                'msg user';

            mensagemUsuario.textContent =
                texto;


            /* Adiciona visualmente no chat */

            caixa.appendChild(
                mensagemUsuario
            );


            /* =================================
               REMOVE MENSAGEM INICIAL
            ================================= */

            var vazio =
                caixa.querySelector('.vazio');

            if (vazio) {
                vazio.remove();
            }


            /* =================================
               LIMPA O INPUT
               
               Usamos setTimeout para deixar
               o navegador iniciar o envio
               do formulário primeiro.
            ================================= */

            setTimeout(function () {

                input.value = '';

            }, 0);


            /* =================================
               SCROLL PARA A MENSAGEM
            ================================= */

            setTimeout(function () {

                caixa.scrollTo({

                    top:
                        caixa.scrollHeight,

                    behavior:
                        'smooth'

                });

            }, 50);


            /* =================================
               ANIMAÇÃO DO BOTÃO
            ================================= */

            botao.style.transform =
                'scale(.88)';

            setTimeout(function () {

                botao.style.transform =
                    '';

            }, 180);


            /* =================================
               INDICADOR DE DIGITAÇÃO
            ================================= */

            var digitando =
                document.createElement('div');

            digitando.className =
                'msg bot digitando';

            digitando.innerHTML = `
                <span></span>
                <span></span>
                <span></span>
            `;


            /* Adiciona as bolinhas */

            caixa.appendChild(
                digitando
            );


            /* =================================
               SCROLL PARA AS BOLINHAS
            ================================= */

            setTimeout(function () {

                caixa.scrollTo({

                    top:
                        caixa.scrollHeight,

                    behavior:
                        'smooth'

                });

            }, 100);

        }
    );


    /* =================================
       ENTER PARA ENVIAR
    ================================= */

    input.addEventListener(
        'keydown',
        function (event) {

            if (
                event.key === 'Enter' &&
                !event.shiftKey
            ) {

                event.preventDefault();

                formulario.requestSubmit();

            }

        }
    );


    /* =================================
       FOCO AUTOMÁTICO
    ================================= */

    input.focus();

</script>



</body>
</html>
